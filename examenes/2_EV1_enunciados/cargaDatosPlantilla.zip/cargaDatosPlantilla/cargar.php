<?php
	sleep(7);
	echo "<p>DATOS CARGADOS</p>";
?>